public class Node {
	public Integer value;
	public Node prev;
	public Node next;

	public Node(Integer value) {
		this.value = value;
		this.prev = null;
		this.next = null;
	}
}
