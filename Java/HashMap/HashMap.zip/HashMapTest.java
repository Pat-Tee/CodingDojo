public class HashMapTest {
	public static void main(String[] args) {
		HashMappy hashish = new HashMappy();
		hashish.hash();
	}
}
