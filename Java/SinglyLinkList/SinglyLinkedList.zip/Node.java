public class Node {
	public int value;
	public Node next;
//CONSTRUCTORS
	public Node(int value) {
		next = null;
		this.value = value;
	}
}
