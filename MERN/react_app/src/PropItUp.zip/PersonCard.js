import React from 'react';

/////////////////////
// Prop It Up
/////////////////////
class PersonCard extends React.Component {
    render() {
    const { firstName, lastName, age, hairColor } = this.props;
    return (            
        <>                
            <h3>{lastName}, {firstName}</h3>                
            <p>Age: {age}</p>
            <p>Hair color: {hairColor}</p>            
        </>        
        );    
    }
}

export default PersonCard;