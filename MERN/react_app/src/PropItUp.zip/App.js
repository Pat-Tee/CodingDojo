import React from 'react';
import './App.css';
import PersonCard from './PersonCard';

function App() {
  return (
    <div className="App">

      <ul>
        <li><PersonCard firstName="John" lastName="Stone" age={50} hairColor="brown" /></li>
        <li><PersonCard firstName="Julie" lastName="Stone" age={45} hairColor="brown" /></li>
        <li><PersonCard firstName="Zoey" lastName="Stone" age={10} hairColor="brown" /></li>
        <li><PersonCard firstName="Junior" lastName="Stone" age={12} hairColor="brown" /></li>
      </ul>
      
    </div>
  );
}

// function App() {
//   return (
//     <div className="App">

//       <h1>Hello Dojo!</h1>
//       <h3>Things I need to do:</h3>
//       <ul>
//         <li>Learn React</li>
//         <li>Write a resume</li>
//         <li>Find a job</li>
//         <li>Profit</li>
//       </ul>
      
//     </div>
//   );
// }

export default App;
