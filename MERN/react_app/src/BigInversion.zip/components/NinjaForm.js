import React, {useState} from 'react';


const NinjaForm = () => {

    const [formInfo, setFormInfo] = useState({
        name:"",
        imgLink:""
    });

    const [listOfPersons, setListOfPersons] = useState([]);

    const changeHandler = (e) => {
        console.log("you've changed an input", e.target.name, e.target.value);
        setFormInfo({
            ...formInfo,
            [e.target.name]: [e.target.value]
        })
    }

    const addPerson = (e) => {
        e.preventDefault();
        console.log("form submitted");
        console.log(formInfo);
        setListOfPersons([...listOfPersons, formInfo]);
    }

    return ( <div>
        <form onSubmit= { (e)=>addPerson(e) }>
            <div className="form-group">
                <label htmlFor="">Name:</label>
                <input onChange= { (e)=>changeHandler(e) } type="text" name="name" id="" className="form-control"/>
            </div>
            <div className="form-group">
                <label htmlFor="">Image Link:</label>
                <input onChange= { (e)=>changeHandler(e) } type="text" name="imgLnk" id="" className="form-control"/>
            </div>
            <input type="submit" value="Add" className="btn btn-success mt-3"/>
        </form>
        <hr />

        { listOfPersons.map((person,i) =>{ 
            return <div style = {{backgroundColor : "blue"}} className="card">
                <img className="card-img-top" src="/images/pathToYourImage.png" alt="Card"/>
                <div className="card-body">
                    <h4 className="card-title">{person.name}</h4>
                    <p className="card-text">
                        Some quick example text to build on the card title
                        and make up the bulk of the card's content.
                    </p>
                    <a href="#!" className="btn btn-primary">Go somewhere</a>
                </div>
            </div>  }) }
        </div> )
}


export default NinjaForm