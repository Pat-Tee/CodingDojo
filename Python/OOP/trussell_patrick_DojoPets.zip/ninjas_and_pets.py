from pets import *
from ninjas import *

ninja = Ninja("Leo", "Turtle", 'catnip', 'wet canned cat food', Pet("Kitteh", "cat"))

ninja.walk().feed().bath()

Bolt = serviceAnimal("Bolt")
Bolt.doJob("attack")