import parent

print(locals())
