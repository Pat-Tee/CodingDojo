from flask import Flask

app = Flask(__name__)
app.secret_key = '91^64.3[4 42'
